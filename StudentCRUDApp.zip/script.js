const studentForm = document.getElementById("studentForm");
const studentList = document.getElementById("studentList");
let students = [
  { fullName: "Aryan Sharma", email: "aryan@gmail.com", phone: "9876543210", age: 20, course: "B.Tech", enroll: "ECE2025IND001" },
  { fullName: "Sneha Patel", email: "sneha@gmail.com", phone: "9090909090", age: 19, course: "B.Sc", enroll: "BIO2025IND002" },
  { fullName: "Ravi Kumar", email: "ravi@gmail.com", phone: "9812345678", age: 21, course: "B.Com", enroll: "COM2025IND003" },
  { fullName: "Aarti Verma", email: "aarti@gmail.com", phone: "9123456789", age: 22, course: "B.A", enroll: "ART2025IND004" },
  { fullName: "Karan Singh", email: "karan@gmail.com", phone: "7001234567", age: 23, course: "M.Tech", enroll: "CSE2025IND005" }
];
function displayStudents() {
  studentList.innerHTML = students.map((stu, index) => `
    <div class="student-card">
      <h3>👨‍🎓 ${stu.fullName}</h3>
      <p>📧 ${stu.email}</p>
      <p>📱 ${stu.phone}</p>
      <p>🎓 ${stu.course} | 🆔 ${stu.enroll}</p>
      <button onclick="editStudent(${index})">✏️ Edit</button>
      <button onclick="deleteStudent(${index})">🗑️ Delete</button>
    </div>
  `).join("");
}
studentForm.addEventListener("submit", function (e) {
  e.preventDefault();
  const newStudent = {
    fullName: document.getElementById("fullName").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    age: document.getElementById("age").value,
    course: document.getElementById("course").value,
    enroll: document.getElementById("enroll").value
  };
  students.push(newStudent);
  displayStudents();
  studentForm.reset();
});
function deleteStudent(index) {
  students.splice(index, 1);
  displayStudents();
}
function editStudent(index) {
  const stu = students[index];
  document.getElementById("fullName").value = stu.fullName;
  document.getElementById("email").value = stu.email;
  document.getElementById("phone").value = stu.phone;
  document.getElementById("age").value = stu.age;
  document.getElementById("course").value = stu.course;
  document.getElementById("enroll").value = stu.enroll;
  students.splice(index, 1);
}
displayStudents();
